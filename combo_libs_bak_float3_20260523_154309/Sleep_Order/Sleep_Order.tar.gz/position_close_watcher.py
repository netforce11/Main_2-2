"""
position_close_watcher.py — 포지션 청산 예약 감시 v3.0
════════════════════════════════════════════════════════════════
동작:
  From ~ To KST 시간 창 안에서 1초마다 폴링
  현재가(current) ≤ 설정가 - 2틱  →  사정권 도달
  즉시 설정가로 선매도 주문 발사
  미체결 → -1틱씩 정정 최대 N회
  초과 → 시장가 전환

자정 넘기는 경우 처리:
  From=23:00, To=01:30 이면
  datetime 기반으로 날짜 넘김 정확히 계산
════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import threading
from datetime import datetime, timedelta, time as dtime
from typing import Optional

from PyQt5.QtCore import QObject, QTimer, pyqtSignal

try:
    from zoneinfo import ZoneInfo
except ImportError:
    try:
        from backports.zoneinfo import ZoneInfo   # type: ignore
    except ImportError:
        ZoneInfo = None                           # type: ignore

_KST     = ZoneInfo("Asia/Seoul") if ZoneInfo else None
_N_SLOTS = 3


# ── 틱 크기 ────────────────────────────────────────────────────
def _tick_size(price: float) -> float:
    return 0.10 if price >= 3.00 else 0.05


# ── 사정권 판단: current ≤ 설정가 - 2틱 ──────────────────────
def _in_range(current: float, target: float) -> bool:
    tick      = _tick_size(target)
    threshold = round(target - 2 * tick, 2)
    return current <= threshold


# ── 자정 넘기는 시간 범위 판단 ────────────────────────────────
def _in_time_window(now_dt: datetime, from_str: str, to_str: str) -> bool:
    """
    now_dt: KST datetime (tzinfo 포함 or naive)
    from_str, to_str: "HH:MM"

    자정을 넘기는 경우(예: 23:00 ~ 01:30) 도 정확히 처리.
    """
    fh, fm = map(int, from_str.split(":"))
    th, tm = map(int, to_str.split(":"))

    # 오늘 날짜 기준 from/to datetime 구성
    today   = now_dt.date()
    from_dt = datetime(today.year, today.month, today.day, fh, fm,
                       tzinfo=now_dt.tzinfo)
    to_dt   = datetime(today.year, today.month, today.day, th, tm,
                       tzinfo=now_dt.tzinfo)

    # to < from 이면 자정을 넘기는 범위 → to 를 +1일로
    if to_dt <= from_dt:
        to_dt += timedelta(days=1)

    return from_dt <= now_dt <= to_dt


# ── 텔레그램 ───────────────────────────────────────────────────
def _tg(msg: str) -> None:
    def _run():
        try:
            from telegram_bot.tg_client import TelegramClient
            TelegramClient.get()._send_raw(msg)
        except Exception as e:
            print(f"[ClosWatcher] TG 실패: {e}")
    threading.Thread(target=_run, daemon=True).start()


# ══════════════════════════════════════════════════════════════
# 슬롯 상태
# ══════════════════════════════════════════════════════════════
class _SlotState:
    IDLE    = "idle"
    WAITING = "waiting"   # 시간 창 대기 / 가격 감시 중
    ORDERED = "ordered"   # 주문 발사 후 체결 대기
    DONE    = "done"

    def __init__(self, idx: int):
        self.idx              = idx
        self.state            = self.IDLE
        self.pos: dict | None = None
        self.ref              = None
        self.order_price      = 0.0   # 발사된 주문가 (설정가)
        self.correction_count = 0

    def reset(self):
        self.state            = self.IDLE
        self.pos              = None
        self.ref              = None
        self.order_price      = 0.0
        self.correction_count = 0


# ══════════════════════════════════════════════════════════════
# PositionCloseWatcher
# ══════════════════════════════════════════════════════════════
class PositionCloseWatcher(QObject):
    """
    포지션 청산 예약 감시 싱글톤.
    Signals:
        slot_status_changed(int, str)
    """
    slot_status_changed = pyqtSignal(int, str)

    _instance: "PositionCloseWatcher | None" = None

    @classmethod
    def get(cls) -> "PositionCloseWatcher":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self, parent=None):
        super().__init__(parent)
        self._slots = [_SlotState(i) for i in range(_N_SLOTS)]
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick_all)
        self._timer.start()

    # ── Public API ────────────────────────────────────────────

    def register(self, idx: int, pos: dict, ref) -> None:
        from Sleep_Order.position_close_config import pos_close_cfg
        slot = self._slots[idx]
        slot.state            = _SlotState.WAITING
        slot.pos              = dict(pos)
        slot.ref              = ref
        slot.correction_count = 0

        cfg   = pos_close_cfg.get_slot(idx)
        strat = pos.get("strategy", "")
        oid   = pos.get("oid")
        frm   = cfg["close_from_kst"]
        to    = cfg["close_to_kst"]
        price = cfg["close_premium_price"]
        max_c = cfg["close_max_corrections"]
        tick  = _tick_size(price)
        thresh = round(price - 2 * tick, 2)

        pos_close_cfg.register_position(idx, pos)
        self._emit(idx, f"⏳ 감시중 — {frm}~{to} KST")
        _tg(
            f"🔔 [슬롯{idx+1}] 청산 예약 등록\n"
            f"📌 {strat}  OID={oid}\n"
            f"⏰ {frm} ~ {to} KST\n"
            f"💰 선매도가: ${price:.2f}  사정권: ≤${thresh:.2f}\n"
            f"🔄 최대 {max_c}회 정정"
        )
        print(f"[ClosWatcher] 슬롯{idx+1} 등록: OID={oid} / "
              f"{frm}~{to} KST / 선매도 ${price:.2f} / 사정권 ≤${thresh:.2f}")

    def cancel(self, idx: int) -> None:
        from Sleep_Order.position_close_config import pos_close_cfg
        slot = self._slots[idx]
        if slot.state == _SlotState.ORDERED:
            self._emit(idx, "⚠️ 주문 발사 후 취소 불가")
            return
        strat = (slot.pos or {}).get("strategy", "")
        slot.reset()
        pos_close_cfg.clear_slot(idx)
        self._emit(idx, "⏸ 비활성")
        _tg(f"🚫 [슬롯{idx+1}] 청산 예약 취소: {strat}")

    def is_active(self, idx: int) -> bool:
        return self._slots[idx].state not in (_SlotState.IDLE, _SlotState.DONE)

    # ── 1초 폴링 ──────────────────────────────────────────────

    def _tick_all(self) -> None:
        for slot in self._slots:
            try:
                if slot.state == _SlotState.WAITING:
                    self._tick_waiting(slot)
                elif slot.state == _SlotState.ORDERED:
                    self._tick_ordered(slot)
            except Exception as e:
                print(f"[ClosWatcher] 슬롯{slot.idx+1} tick 오류: {e}")

    def _tick_waiting(self, slot: _SlotState) -> None:
        from Sleep_Order.position_close_config import pos_close_cfg
        cfg   = pos_close_cfg.get_slot(slot.idx)
        frm   = cfg["close_from_kst"]
        to    = cfg["close_to_kst"]
        price = float(cfg["close_premium_price"])

        # 수동 청산 감지
        if not self._pos_exists(slot):
            self._finish(slot, "잔고에서 사라짐 (수동 청산)")
            return

        now_dt = self._now_kst_dt()

        # 시간 창 밖이면 대기
        if not _in_time_window(now_dt, frm, to):
            # 시간 창이 완전히 지났는지 체크 (To 이후)
            if self._window_passed(now_dt, frm, to):
                self._finish(slot, f"시간 창 종료 ({frm}~{to} KST) — 미발사")
            return

        # 시간 창 안 — 현재가 가져오기
        current = self._get_current_price(slot)
        if current is None:
            self._emit(slot.idx, f"⏳ 감시중 — 현재가 수신 대기")
            return

        tick   = _tick_size(price)
        thresh = round(price - 2 * tick, 2)

        self._emit(slot.idx,
                   f"👁 감시중 | 현재 ${current:.2f} → 사정권 ≤${thresh:.2f}")

        # 사정권 도달 → 선매도 발사
        if _in_range(current, price):
            slot.order_price = price   # 주문가 = 설정가 (선매도)
            slot.state       = _SlotState.ORDERED
            self._send_order(slot, is_correction=False)

    def _tick_ordered(self, slot: _SlotState) -> None:
        from Sleep_Order.position_close_config import pos_close_cfg
        cfg   = pos_close_cfg.get_slot(slot.idx)
        max_c = int(cfg["close_max_corrections"])

        # 체결 확인 — 잔고에서 oid 사라짐
        if not self._pos_exists(slot):
            self._finish(slot, "체결 완료")
            return

        # 미체결 → 정정 or 시장가
        if slot.correction_count >= max_c:
            self._send_market(slot)
        else:
            tick         = _tick_size(slot.order_price)
            new_p        = max(0.01, round(slot.order_price - tick, 2))
            slot.order_price = new_p
            self._send_order(slot, is_correction=True)

    # ── 주문 발사 ─────────────────────────────────────────────

    def _send_order(self, slot: _SlotState, is_correction: bool) -> None:
        if is_correction:
            slot.correction_count += 1
            label = f"정정 #{slot.correction_count}"
        else:
            label = "선매도 발사"

        price = slot.order_price
        strat = (slot.pos or {}).get("strategy", "")
        oid   = (slot.pos or {}).get("oid")

        try:
            from combo_order_logic import _on_close_position_order
            _on_close_position_order(slot.ref, slot.pos, lmt_price=price)

            self._emit(slot.idx, f"📤 {label} | ${price:.2f}")
            _tg(
                f"{'🔄 정정' if is_correction else '📤 선매도 발사'} [슬롯{slot.idx+1}]\n"
                f"({label})  📌 {strat}  OID={oid}\n"
                f"💰 주문가: ${price:.2f}"
            )
            print(f"[ClosWatcher] 슬롯{slot.idx+1} {label}: "
                  f"OID={oid} ${price:.2f}")

        except Exception as e:
            self._emit(slot.idx, f"⚠️ {label} 실패: {e}")
            print(f"[ClosWatcher] 슬롯{slot.idx+1} {label} 실패: {e}")
            if not is_correction:
                slot.state = _SlotState.WAITING   # 첫 주문 실패 → 재시도

    def _send_market(self, slot: _SlotState) -> None:
        strat = (slot.pos or {}).get("strategy", "")
        oid   = (slot.pos or {}).get("oid")
        try:
            from combo_order_logic import _on_close_position_order
            _on_close_position_order(slot.ref, slot.pos, lmt_price=None)

            self._emit(slot.idx,
                       f"🚨 시장가 전환 (정정 {slot.correction_count}회 초과)")
            _tg(
                f"🚨 [슬롯{slot.idx+1}] 시장가 전환\n"
                f"📌 {strat}  OID={oid}\n"
                f"정정 {slot.correction_count}회 초과"
            )
            slot.correction_count = 9999
        except Exception as e:
            self._emit(slot.idx, f"⚠️ 시장가 전환 실패: {e}")

    def _finish(self, slot: _SlotState, reason: str) -> None:
        from Sleep_Order.position_close_config import pos_close_cfg
        strat = (slot.pos or {}).get("strategy", "")
        oid   = (slot.pos or {}).get("oid")
        self._emit(slot.idx, f"✅ {reason}")
        _tg(
            f"✅ [슬롯{slot.idx+1}] 완료\n"
            f"📌 {strat}  OID={oid}\n사유: {reason}"
        )
        print(f"[ClosWatcher] 슬롯{slot.idx+1} 완료: {reason}")
        pos_close_cfg.clear_slot(slot.idx)
        slot.reset()
        slot.state = _SlotState.DONE
        QTimer.singleShot(5000, lambda: self._reset_idle(slot.idx))

    def _reset_idle(self, idx: int) -> None:
        if self._slots[idx].state == _SlotState.DONE:
            self._slots[idx].state = _SlotState.IDLE
            self._emit(idx, "⏸ 비활성")

    # ── 잔고 / 현재가 헬퍼 ───────────────────────────────────

    def _pos_exists(self, slot: _SlotState) -> bool:
        if not slot.pos:
            return False
        oid = slot.pos.get("oid")
        if oid is None:
            return False
        try:
            panel     = getattr(slot.ref, "synthetic_panel", None)
            positions = getattr(panel, "_positions", []) if panel else []
            return any(p.get("oid") == oid for p in positions)
        except Exception as e:
            print(f"[ClosWatcher] 잔고 확인 오류: {e}")
            return True

    def _get_current_price(self, slot: _SlotState) -> Optional[float]:
        """panel._positions 에서 해당 포지션의 current 가져오기."""
        if not slot.pos:
            return None
        oid = slot.pos.get("oid")
        try:
            panel     = getattr(slot.ref, "synthetic_panel", None)
            positions = getattr(panel, "_positions", []) if panel else []
            for p in positions:
                if p.get("oid") == oid:
                    cur = p.get("current", p.get("entry", 0))
                    return float(cur) if cur else None
        except Exception as e:
            print(f"[ClosWatcher] 현재가 조회 오류: {e}")
        return None

    # ── 시각 유틸 ─────────────────────────────────────────────

    def _now_kst_dt(self) -> datetime:
        """현재 KST datetime (초 단위, tzinfo 포함)."""
        if _KST:
            return datetime.now(_KST).replace(second=0, microsecond=0)
        from datetime import timezone, timedelta
        utc_now = datetime.utcnow().replace(second=0, microsecond=0)
        return utc_now + timedelta(hours=9)

    @staticmethod
    def _window_passed(now_dt: datetime, frm: str, to: str) -> bool:
        """
        To 시각이 완전히 지났는지 판단.
        자정 넘김 처리: to < from 이면 to 는 다음날.
        """
        fh, fm = map(int, frm.split(":"))
        th, tm = map(int, to.split(":"))
        today  = now_dt.date()
        from_dt = datetime(today.year, today.month, today.day, fh, fm,
                           tzinfo=now_dt.tzinfo)
        to_dt   = datetime(today.year, today.month, today.day, th, tm,
                           tzinfo=now_dt.tzinfo)
        if to_dt <= from_dt:
            to_dt += timedelta(days=1)
        # now 가 to 를 지났으면 True
        return now_dt > to_dt

    def _emit(self, idx: int, text: str) -> None:
        self.slot_status_changed.emit(idx, text)
